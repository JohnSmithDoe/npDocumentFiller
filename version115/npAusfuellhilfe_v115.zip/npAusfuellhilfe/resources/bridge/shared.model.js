"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EAppChannels = void 0;
var EAppChannels;
(function (EAppChannels) {
    EAppChannels["GET"] = "get-templates";
    EAppChannels["GET_PROFILES"] = "get-profiles";
    EAppChannels["REMOVE"] = "remove-template";
    EAppChannels["OPEN"] = "open-file";
    EAppChannels["OPEN_OUTPUT"] = "open-output";
    EAppChannels["SAVE"] = "save-templates";
    EAppChannels["SAVE_PROFILES"] = "save-profiles";
    EAppChannels["ADD"] = "add-template";
    EAppChannels["REMAP"] = "remap-template";
    EAppChannels["EXPORT"] = "export-templates";
    EAppChannels["FINISHED_LOAD"] = "finished-loading";
    EAppChannels["CLIENT_UPDATE"] = "client-update";
    EAppChannels["CLIENT_ERROR"] = "client-error";
})(EAppChannels = exports.EAppChannels || (exports.EAppChannels = {}));
//# sourceMappingURL=shared.model.js.map