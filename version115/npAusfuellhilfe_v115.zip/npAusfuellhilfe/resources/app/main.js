"use strict";
// noinspection JSIgnoredPromiseFromCall
Object.defineProperty(exports, "__esModule", { value: true });
var electron_1 = require("electron");
var fs = require("fs");
var path = require("path");
var url = require("url");
var shared_model_1 = require("../bridge/shared.model");
var np_assistant_1 = require("./np-assistant");
var win = null;
var args = process.argv.slice(1), serve = args.some(function (val) { return val === '--serve'; });
function createWindow() {
    // Create the browser window.
    win = new electron_1.BrowserWindow({
        frame: true,
        autoHideMenuBar: true,
        width: 1024,
        height: 800,
        backgroundColor: '#fafafa',
        center: true,
        webPreferences: {
            nodeIntegration: true,
            allowRunningInsecureContent: serve,
            contextIsolation: false,
            devTools: serve,
        },
    });
    var indexUrl = 'http://localhost:4200';
    if (serve) {
        require('electron-debug')();
        require('electron-reloader')(module, { ignore: /data|[\/\\]\./, argv: [] });
    }
    else {
        // Path when running electron executable
        var pathIndex = '../renderer/index.html';
        if (fs.existsSync(path.join(__dirname, '../dist/renderer/index.html'))) {
            // Path when running electron in local folder
            pathIndex = '../dist/renderer/index.html';
        }
        // noinspection JSDeprecatedSymbols
        indexUrl = url.format({
            pathname: path.join(__dirname, pathIndex),
            protocol: 'file:',
            slashes: true,
        });
    }
    var assistant;
    // Emitted when the window is closed.
    win.on('closed', function () {
        // Dereference the window object, usually you would store window
        // in an array if your app supports multi windows, this is the time
        // when you should delete the corresponding element.
        win = null;
    });
    win.webContents.on('did-fail-load', function (event, errorCode, errorDesc, validatedURL, isMain) {
        win.loadURL(indexUrl); // REDIRECT TO FIRST WEBPAGE AGAIN
    });
    win.webContents.on('did-finish-load', function (event, errorCode, errorDesc, validatedURL, isMain) {
        if (assistant) {
            var initialData = { documents: assistant.documents, profiles: assistant.profiles };
            event.sender.send(shared_model_1.EAppChannels.FINISHED_LOAD, initialData);
        }
    });
    try {
        assistant = new np_assistant_1.NpAssistant(win);
        win.loadURL(indexUrl);
    }
    catch (e) {
        console.log(e);
        electron_1.app.quit();
    }
}
try {
    // This method will be called when Electron has finished
    // initialization and is ready to create browser windows.
    // Some APIs can only be used after this event occurs.
    electron_1.app.on('ready', function () { return createWindow(); });
    // Quit when all windows are closed.
    electron_1.app.on('window-all-closed', function () {
        // On OS X it is common for applications and their menu bar
        // to stay active until the user quits explicitly with Cmd + Q
        if (process.platform !== 'darwin') {
            electron_1.app.quit();
        }
    });
    electron_1.app.on('activate', function () {
        // On OS X it's common to re-create a window in the app when the
        // dock icon is clicked and there are no other windows open.
        if (win === null) {
            createWindow();
        }
    });
}
catch (e) {
    // Catch Error
    // throw e;
}
//# sourceMappingURL=main.js.map