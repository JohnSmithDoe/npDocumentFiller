"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.startWithExpolorer = void 0;
var child_process = require("child_process");
/**
 * cmd.exe's internal start command by default interprets a "..."-enclosed 1st argument as the window
 * title for the new console window to create (which doesn't apply here).
 * By supplying a (dummy) window title * - "" - explicitly,
 * the 2nd argument is reliably interpreted as the target executable / document path.
 */
function startWithExpolorer(filename) {
    child_process.exec("start \"\" \"".concat(filename, "\""));
}
exports.startWithExpolorer = startWithExpolorer;
//# sourceMappingURL=shell.utils.js.map