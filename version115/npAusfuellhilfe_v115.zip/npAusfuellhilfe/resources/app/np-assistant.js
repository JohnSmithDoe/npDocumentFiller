"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.NpAssistant = void 0;
var ExcelJS = require("exceljs");
var fs = require("fs");
var path = require("path");
var path_1 = require("path");
var uuid_1 = require("uuid");
var api_1 = require("./api");
var pdf_service_1 = require("./pdf/pdf.service");
var electron_utils_1 = require("./utils/electron.utils");
var shell_utils_1 = require("./utils/shell.utils");
var args = process.argv.slice(1), debug = args.some(function (val) { return val === '--npdebug'; });
var npConfigFile = path.resolve('./.npconfig');
var npConfig = {};
try {
    var npConfigContent = fs.readFileSync(npConfigFile, { encoding: 'utf8' });
    npConfig = JSON.parse(npConfigContent);
}
catch (e) {
    console.error(e);
}
var dataPath = npConfig.DATA_PATH || process.env.APP_DATA || path.resolve('./data');
var tmpPath = npConfig.TMP_PATH || process.env.APP_TEMP || path.join(dataPath, 'tmp');
var cachePath = npConfig.CACHE_PATH || process.env.APP_CACHE || path.join(dataPath, 'cache');
var outputPath = npConfig.OUTPUT_PATH || process.env.APP_OUTPUT || path.join(dataPath, 'out');
var dataFile = npConfig.DB_FILE || process.env.APP_CONFIG || path.join(dataPath, 'data.db');
var profileFile = npConfig.PROFILE_FILE || process.env.APP_CONFIG || path.join(dataPath, 'profiles.db');
// Get the pdftk.exe
var pdftk = npConfig.PDFTK_EXE || process.env.APP_PDFTK_EXE || (0, path_1.resolve)((0, path_1.join)('.', 'pdftk', 'bin', 'pdftk.exe'));
// To get the encoding of a file we need to "guess" so we only split win and others :)
var encoding = npConfig.ENCODING || process.env.APP_ENCODING || (process.platform === 'win32' ? 'win1252' : 'utf8');
if (debug) {
    console.log(npConfig, pdftk);
    try {
        npConfig.DATA_PATH = dataPath;
        npConfig.TMP_PATH = tmpPath;
        npConfig.CACHE_PATH = cachePath;
        npConfig.OUTPUT_PATH = outputPath;
        npConfig.DB_FILE = dataFile;
        npConfig.PROFILE_FILE = profileFile;
        npConfig.PDFTK_EXE = pdftk;
        npConfig.ENCODING = encoding;
        var content = JSON.stringify(npConfig);
        fs.writeFileSync(npConfigFile, content, { encoding: 'utf8' });
    }
    catch (e) {
        console.error(e);
    }
}
var NpAssistant = /** @class */ (function () {
    function NpAssistant(mainWindow) {
        this.mainWindow = mainWindow;
        this.database = {};
        this.database = NpAssistant.readDatabase();
        this.api = new api_1.ApiController(this);
        if (!fs.existsSync(pdftk)) {
            throw new Error('Es muss das PDFToolkit installiert sein. https://www.pdflabs.com/tools/pdftk-the-pdf-toolkit/. Falls Du dies schon installiert hast lege bitte eine .npconfig Datei mit dem passenden schema an.');
        }
        this.pdf = new pdf_service_1.PdfService(pdftk, encoding);
    }
    NpAssistant.readDatabase = function () {
        if (fs.existsSync(dataFile)) {
            var content = fs.readFileSync(dataFile, { encoding: 'utf8' });
            return JSON.parse(content);
        }
        else {
            if (!fs.existsSync(dataPath)) {
                fs.mkdirSync(dataPath);
                fs.mkdirSync(tmpPath);
                fs.mkdirSync(cachePath);
                fs.mkdirSync(outputPath);
            }
            return {};
        }
    };
    NpAssistant.writeDatabase = function (database) {
        try {
            fs.writeFileSync(dataFile, JSON.stringify(database), { encoding: 'utf8' });
        }
        catch (e) {
            console.error(e);
        }
    };
    NpAssistant.readProfiles = function () {
        if (fs.existsSync(profileFile)) {
            var content = fs.readFileSync(profileFile, { encoding: 'utf8' });
            return JSON.parse(content);
        }
        return [];
    };
    NpAssistant.writeProfiles = function (profiles) {
        try {
            fs.writeFileSync(profileFile, JSON.stringify(profiles), { encoding: 'utf8' });
        }
        catch (e) {
            console.error(e);
        }
    };
    NpAssistant.copyToTempFolder = function (filename) {
        var basename = path.basename(filename);
        var tmpCopy = path.join(tmpPath, basename);
        fs.copyFileSync(filename, tmpCopy);
        return tmpCopy;
    };
    NpAssistant.removeTempCopy = function (filename) {
        var basename = path.basename(filename);
        var tmpCopy = path.join(tmpPath, basename);
        if (!debug)
            fs.rmSync(tmpCopy);
        return tmpCopy;
    };
    NpAssistant.extractFDFToTemp = function (filename, pdfService) {
        var ext = path.extname(filename);
        var basenameNoExt = path.basename(filename, ext);
        var fdfFile = path.join(tmpPath, basenameNoExt + '.fdf');
        pdfService.extractFDF(filename, fdfFile);
        return fdfFile;
    };
    NpAssistant.getFileStats = function (filename) {
        var ext = path.extname(filename);
        var basename = path.basename(filename);
        var basenameNoExt = path.basename(filename, ext);
        var type = ext === '.pdf' ? 'pdf' : ext === '.xlsx' ? 'xlsx' : 'resource';
        var mtimeMs = fs.statSync(filename).mtimeMs;
        return { basename: basename, basenameNoExt: basenameNoExt, type: type, mtimeMs: mtimeMs };
    };
    NpAssistant.createAndValidateOutputFolder = function (outputFolder, foldername) {
        var result = [];
        var valid = true;
        if (!fs.existsSync(outputFolder)) {
            fs.mkdirSync(outputFolder);
            result.push("Ordner wurde erstellt: ".concat(outputFolder));
        }
        else {
            valid = false;
            result.push("Ordner existierte bereits: ".concat(outputFolder));
            result.push('Erstellen wurde abgebrochen damit keine Daten überschrieben werden.');
            result.push('Bitte warte eine Minute, lösche den Ordner oder verwende ein anderes suffix');
        }
        return { outputMsgs: result, valid: valid };
    };
    NpAssistant.copyAndValidateOriginal = function (document, database, result) {
        var tmpCopy = NpAssistant.copyToTempFolder(document.filename);
        var mtimeMs = fs.statSync(document.filename).mtimeMs;
        if (document.mtime !== mtimeMs) {
            document.mtime = mtimeMs;
            NpAssistant.writeDatabase(database);
            result.push('*******************');
            result.push("WARNUNG: Die Original Datei [".concat(document.name, "] wurde ver\u00E4ndert!!!"));
            result.push("Bitte \u00FCberpr\u00FCfe ob die Felder noch passen.");
            result.push("Wenn nicht l\u00F6sche am besten das Dokument und f\u00FCge es danach noch einmal neu hinzu.");
            result.push('*******************');
        }
        return tmpCopy;
    };
    Object.defineProperty(NpAssistant.prototype, "documents", {
        get: function () {
            return Object.values(this.database);
        },
        enumerable: false,
        configurable: true
    });
    NpAssistant.prototype.saveTemplate = function (template) {
        this.database[template.filename] = template;
        NpAssistant.writeDatabase(this.database);
    };
    NpAssistant.prototype.removeFileTemplate = function (filename) {
        delete this.database[filename];
        NpAssistant.writeDatabase(this.database);
    };
    NpAssistant.prototype.openFileWithExplorer = function (filename) {
        (0, shell_utils_1.startWithExpolorer)(filename);
    };
    NpAssistant.prototype.openOutputFolderWithExplorer = function (folder) {
        var outputFolder = path.join(outputPath, folder);
        if (!fs.existsSync(outputFolder)) {
            (0, shell_utils_1.startWithExpolorer)(outputPath);
        }
        else {
            (0, shell_utils_1.startWithExpolorer)(outputFolder);
        }
    };
    NpAssistant.prototype.addNewXlsxTemplate = function (filename, basename, basenameNoExt, mtimeMs) {
        return __awaiter(this, void 0, void 0, function () {
            var workbook, tmpCopy, sheets;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        workbook = new ExcelJS.Workbook();
                        tmpCopy = NpAssistant.copyToTempFolder(filename);
                        return [4 /*yield*/, workbook.xlsx.readFile(tmpCopy)];
                    case 1:
                        _a.sent();
                        sheets = workbook.worksheets.map(function (sheet) { return ({ id: (0, uuid_1.v4)(), name: sheet.name }); });
                        if (!sheets) {
                            throw new Error('No Worksheets found');
                        }
                        this.database[filename] = {
                            id: (0, uuid_1.v4)(),
                            name: basename,
                            filename: filename,
                            sheets: sheets,
                            mapped: [],
                            export: true,
                            type: 'xlsx',
                            mtime: mtimeMs
                        };
                        NpAssistant.removeTempCopy(tmpCopy);
                        return [2 /*return*/];
                }
            });
        });
    };
    NpAssistant.prototype.addNewPdfTemplate = function (filename, basename, basenameNoExt, mtimeMs) {
        var previewfile = path.join(cachePath, basenameNoExt + '-preview-data.pdf');
        var tmpCopy = NpAssistant.copyToTempFolder(filename);
        var fdfFile = NpAssistant.extractFDFToTemp(tmpCopy, this.pdf);
        var _a = this.pdf.readFDF(fdfFile), fdf = _a.fdf, allValues = _a.allValues;
        // map allValues to Feld # or original id and write a preview file
        var fields = allValues
            .map(function (fdfValue, index) {
            fdfValue.value = fdfValue.path;
            return fdfValue;
        })
            .map(function (fdfValue) { return ({ id: (0, uuid_1.v4)(), name: fdfValue.path }); });
        this.pdf.writeFDF(fdfFile, fdf);
        this.pdf.applyFDF(tmpCopy, fdfFile, previewfile);
        NpAssistant.removeTempCopy(fdfFile);
        NpAssistant.removeTempCopy(filename);
        this.database[filename] = {
            id: (0, uuid_1.v4)(),
            name: basename,
            filename: filename,
            fields: fields,
            mapped: [],
            export: true,
            type: 'pdf',
            mtime: mtimeMs,
            previewfile: previewfile
        };
        (0, shell_utils_1.startWithExpolorer)(previewfile);
    };
    NpAssistant.prototype.remapDocument = function (filename) {
        if (!this.database[filename])
            throw new Error('Dieses Dokument existiert nicht mehr. Bitte wenden Sie sich an Ihren persönlichen Ansprechpartner für IT-Probleme.');
        var newfilename = (0, electron_utils_1.showFilePickerSync)(this.mainWindow, {
            defaultPath: path.dirname(filename), title: 'Dokument neu verknüpfen'
        });
        if (fs.existsSync(newfilename)) {
            var _a = NpAssistant.getFileStats(newfilename), basename = _a.basename, type = _a.type, mtimeMs = _a.mtimeMs;
            var oldDoc = this.database[filename];
            if (type !== oldDoc.type)
                throw new Error('Es kann hier nur eine Änderung des Dateinamens vorgenommen werden. Eine Änderung der Vorlage geht nur über löschen und neu anlegen.');
            oldDoc.filename = newfilename;
            oldDoc.name = basename;
            oldDoc.mtime = mtimeMs;
            delete this.database[filename];
            this.database[newfilename] = oldDoc;
            NpAssistant.writeDatabase(this.database);
        }
        else {
            if (newfilename)
                throw new Error('Die gewählte Datei konnte nicht gelesen werden. Bitte wenden Sie sich an Ihren persönlichen Ansprechpartner für IT-Probleme.');
        }
        return this.documents;
    };
    NpAssistant.prototype.addNewFileTemplate = function () {
        return __awaiter(this, void 0, void 0, function () {
            var filename, _a, basename, basenameNoExt, type, mtimeMs;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        filename = (0, electron_utils_1.showFilePickerSync)(this.mainWindow, {
                            defaultPath: '', title: 'Dokument verknüpfen'
                        });
                        if (!fs.existsSync(filename)) return [3 /*break*/, 5];
                        if (!!this.database[filename])
                            throw new Error('Dieses Dokument existiert bereits. Bitte keine doppelten Dokumente anlegen. Bei Problemen entferne die alte Vorlage und beginne von vorne.');
                        _a = NpAssistant.getFileStats(filename), basename = _a.basename, basenameNoExt = _a.basenameNoExt, type = _a.type, mtimeMs = _a.mtimeMs;
                        if (!(type === 'pdf')) return [3 /*break*/, 1];
                        this.addNewPdfTemplate(filename, basename, basenameNoExt, mtimeMs);
                        return [3 /*break*/, 4];
                    case 1:
                        if (!(type === 'xlsx')) return [3 /*break*/, 3];
                        return [4 /*yield*/, this.addNewXlsxTemplate(filename, basename, basenameNoExt, mtimeMs)];
                    case 2:
                        _b.sent();
                        return [3 /*break*/, 4];
                    case 3:
                        this.database[filename] = {
                            id: (0, uuid_1.v4)(),
                            name: basename,
                            filename: filename,
                            export: true,
                            type: 'resource',
                            mtime: mtimeMs
                        };
                        _b.label = 4;
                    case 4:
                        NpAssistant.writeDatabase(this.database);
                        return [3 /*break*/, 6];
                    case 5:
                        if (filename)
                            throw new Error('Die gewählte Datei konnte nicht gelesen werden. Bitte wenden Sie sich an Ihren persönlichen Ansprechpartner für IT-Probleme.');
                        _b.label = 6;
                    case 6: return [2 /*return*/, this.documents];
                }
            });
        });
    };
    // noinspection JSMethodCanBeStatic
    NpAssistant.prototype.applyFieldsToXlsx = function (document, tmpCopy, inputs, outCopy) {
        return __awaiter(this, void 0, void 0, function () {
            var fields, workbook;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        fields = document.mapped.filter(function (field) { return field.export; });
                        workbook = new ExcelJS.Workbook();
                        // read from a file
                        return [4 /*yield*/, workbook.xlsx.readFile(tmpCopy)];
                    case 1:
                        // read from a file
                        _a.sent();
                        fields.forEach(function (mappedField) {
                            var _a;
                            var fullCellId = mappedField.mappedName;
                            var sheetName = fullCellId.slice(1, fullCellId.indexOf('.'));
                            var sheet = workbook.worksheets.find(function (sheet) { return sheet.name === sheetName; });
                            if (sheet) {
                                var cell = fullCellId.slice(fullCellId.indexOf('.') + 1);
                                var value = (_a = inputs.find(function (input) { return input.identifiers.includes(mappedField.origId); })) === null || _a === void 0 ? void 0 : _a.value;
                                if (value) {
                                    sheet.getCell(cell).value = value;
                                }
                            }
                            else {
                                throw new Error('Die Excel Datei enthält keine Arbeitsmappen');
                            }
                        });
                        return [4 /*yield*/, workbook.xlsx.writeFile(outCopy)];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    NpAssistant.prototype.applyFieldsToPdf = function (document, tmpCopy, inputs, outCopy) {
        var fields = document.mapped.filter(function (field) { return field.export; });
        var fdfFile = NpAssistant.extractFDFToTemp(tmpCopy, this.pdf);
        var _a = this.pdf.readFDF(fdfFile), fdf = _a.fdf, allValues = _a.allValues;
        fields.forEach(function (mappedField) {
            var _a;
            var origField = document.fields.find(function (orig) { return orig.id === mappedField.origId; });
            var fdfField = allValues.find(function (fdfValue) { return fdfValue.path === origField.name; });
            var value = (_a = inputs.find(function (input) { return input.identifiers.includes(mappedField.origId); })) === null || _a === void 0 ? void 0 : _a.value;
            if (value) {
                fdfField.value = value;
            }
        });
        this.pdf.writeFDF(fdfFile, fdf);
        this.pdf.applyFDF(tmpCopy, fdfFile, outCopy);
        NpAssistant.removeTempCopy(fdfFile);
    };
    NpAssistant.prototype.createDocuments = function (foldername, inputs) {
        return __awaiter(this, void 0, void 0, function () {
            var outputFolder, _a, outputMsgs, valid, templates, _i, templates_1, document_1, tmpCopy, basename, outCopy;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        outputFolder = path.join(outputPath, foldername);
                        _a = NpAssistant.createAndValidateOutputFolder(outputFolder, foldername), outputMsgs = _a.outputMsgs, valid = _a.valid;
                        if (!valid)
                            throw new Error(outputMsgs.join('||'));
                        templates = this.documents.filter(function (template) { return template.export; });
                        _i = 0, templates_1 = templates;
                        _b.label = 1;
                    case 1:
                        if (!(_i < templates_1.length)) return [3 /*break*/, 7];
                        document_1 = templates_1[_i];
                        tmpCopy = NpAssistant.copyAndValidateOriginal(document_1, this.database, outputMsgs);
                        basename = path.basename(document_1.filename);
                        outCopy = path.join(outputFolder, basename);
                        if (!(document_1.type === 'pdf')) return [3 /*break*/, 2];
                        this.applyFieldsToPdf(document_1, tmpCopy, inputs, outCopy);
                        return [3 /*break*/, 5];
                    case 2:
                        if (!(document_1.type === 'xlsx')) return [3 /*break*/, 4];
                        return [4 /*yield*/, this.applyFieldsToXlsx(document_1, tmpCopy, inputs, outCopy)];
                    case 3:
                        _b.sent();
                        return [3 /*break*/, 5];
                    case 4:
                        fs.copyFileSync(tmpCopy, outCopy);
                        _b.label = 5;
                    case 5:
                        outputMsgs.push("Dokument wurden erstellt: ".concat(basename));
                        NpAssistant.removeTempCopy(tmpCopy);
                        _b.label = 6;
                    case 6:
                        _i++;
                        return [3 /*break*/, 1];
                    case 7:
                        outputMsgs.push("Alle Dokumente wurden erfolgreich erstellt.");
                        return [2 /*return*/, outputMsgs];
                }
            });
        });
    };
    Object.defineProperty(NpAssistant.prototype, "profiles", {
        get: function () {
            return NpAssistant.readProfiles();
        },
        set: function (profiles) {
            NpAssistant.writeProfiles(profiles);
        },
        enumerable: false,
        configurable: true
    });
    return NpAssistant;
}());
exports.NpAssistant = NpAssistant;
//# sourceMappingURL=np-assistant.js.map