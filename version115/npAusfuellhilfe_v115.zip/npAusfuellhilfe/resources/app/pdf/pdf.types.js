"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CFDFError = exports.CFDFTagTarget = exports.CFDFTagValue = exports.CFDFTagKids = exports.CFDFTagClose = exports.CFDFTagOpen = exports.CFDFTrailer = exports.CFDFStarter = exports.CFDFHeader = void 0;
exports.CFDFHeader = String.fromCharCode(226) +
    String.fromCharCode(227) +
    String.fromCharCode(207) +
    String.fromCharCode(211);
// \n on windows only...
exports.CFDFStarter = '%FDF-1.2\n%' + exports.CFDFHeader + '\n1 0 obj \n<<\n/FDF \n<<\n/Fields [\n';
exports.CFDFTrailer = ']\n>>\n>>\nendobj \ntrailer\n\n<<\n/Root 1 0 R\n>>\n%%EOF\n';
exports.CFDFTagOpen = '<<';
exports.CFDFTagClose = '>>';
exports.CFDFTagKids = '/Kids';
exports.CFDFTagValue = '/V';
exports.CFDFTagTarget = '/T';
exports.CFDFError = 'Could not parse FDF. Wrong Format provided!';
//# sourceMappingURL=pdf.types.js.map