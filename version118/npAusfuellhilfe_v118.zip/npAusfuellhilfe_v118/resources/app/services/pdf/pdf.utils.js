"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.assembleFDF = exports.updateFDFValuePaths = exports.parseFDF = exports.parseFields = exports.validateFDF = exports.stripLastChars = void 0;
var pdf_types_1 = require("./pdf.types");
function stripLastChars(txt, chars, trim) {
    if (trim === void 0) { trim = true; }
    var stripped = txt.endsWith(chars) ? txt.substring(0, txt.length - chars.length) : txt;
    return trim ? stripped.trim() : stripped;
}
exports.stripLastChars = stripLastChars;
function stripFirstChars(txt, chars, trim) {
    if (trim === void 0) { trim = true; }
    var stripped = txt.startsWith(chars) ? txt.substring(chars.length) : txt;
    return trim ? stripped.trim() : stripped;
}
function stripBrackets(txt, trim) {
    if (trim === void 0) { trim = true; }
    txt = trim ? txt.trim() : txt;
    if (txt.startsWith('(') && txt.endsWith(')')) {
        txt = txt.substring(1, txt.length - 1);
    }
    return txt;
}
function validateFDF(fileContent, strip) {
    if (strip === void 0) { strip = true; }
    if (!fileContent.startsWith(pdf_types_1.CFDFStarter) || !fileContent.endsWith(pdf_types_1.CFDFTrailer)) {
        throw new Error(pdf_types_1.CFDFError);
    }
    if (strip) {
        fileContent = fileContent.substring(pdf_types_1.CFDFStarter.length, fileContent.length - pdf_types_1.CFDFTrailer.length);
        fileContent = fileContent.replace(/\n/g, '');
        // fileContent = fileContent.replace(/\s/g, '');
        if (!fileContent.endsWith(pdf_types_1.CFDFTagClose)) {
            throw new Error(pdf_types_1.CFDFError);
        }
    }
    return fileContent;
}
exports.validateFDF = validateFDF;
function parseFields(data) {
    var fdf = { kids: [], values: [], parent: null, target: '' };
    var current = fdf;
    var allValues = [];
    while (!!data.length) {
        if (data.startsWith(pdf_types_1.CFDFTagOpen)) {
            data = stripFirstChars(data, pdf_types_1.CFDFTagOpen);
        }
        else if (data.startsWith(pdf_types_1.CFDFTagClose)) {
            data = stripFirstChars(data, pdf_types_1.CFDFTagClose);
        }
        else if (data.startsWith('[')) {
            data = stripFirstChars(data, '[');
        }
        else if (data.startsWith(']')) {
            data = stripFirstChars(data, ']');
        }
        else if (data.startsWith(pdf_types_1.CFDFTagKids)) {
            var kid = { kids: [], values: [], parent: current, target: '' };
            current.kids.push(kid);
            current = kid;
            data = stripFirstChars(data, pdf_types_1.CFDFTagKids);
        }
        else if (data.startsWith(pdf_types_1.CFDFTagValue)) {
            var value = stripBrackets(data.substring(pdf_types_1.CFDFTagValue.length, data.indexOf(pdf_types_1.CFDFTagTarget)));
            data = data.substring(data.indexOf(pdf_types_1.CFDFTagTarget));
            var target = stripBrackets(data.substring(data.indexOf(pdf_types_1.CFDFTagTarget) + pdf_types_1.CFDFTagTarget.length, data.indexOf(pdf_types_1.CFDFTagClose)));
            var valueObj = { value: value, target: target, path: target, parent: current };
            allValues.push(valueObj);
            current.values.push(valueObj);
            data = data.substring(data.indexOf(pdf_types_1.CFDFTagClose) + pdf_types_1.CFDFTagClose.length).trim();
        }
        else if (data.startsWith(pdf_types_1.CFDFTagTarget)) {
            current.target = stripBrackets(data.substring(data.indexOf(pdf_types_1.CFDFTagTarget) + pdf_types_1.CFDFTagTarget.length, data.indexOf(pdf_types_1.CFDFTagClose)));
            current = current.parent;
            data = data.substring(data.indexOf(pdf_types_1.CFDFTagClose) + pdf_types_1.CFDFTagClose.length).trim();
        }
        else {
            // If an unexpected token occurs
            throw new Error(pdf_types_1.CFDFError + data.substring(0, 6));
        }
    }
    return { fdf: fdf, allValues: allValues };
}
exports.parseFields = parseFields;
/** strips the header and trailer of the fdf file and returns only the fields part */
function parseFDF(data) {
    data = validateFDF(data);
    var _a = parseFields(data), fdf = _a.fdf, allValues = _a.allValues;
    updateFDFValuePaths(allValues);
    return { fdf: fdf, allValues: allValues };
}
exports.parseFDF = parseFDF;
// update paths of values with the value of a tree walk up
function updateFDFValuePaths(allValues) {
    function getPath(value) {
        return (value.parent ? getPath(value.parent) : '') + value.target;
    }
    allValues.forEach(function (value) {
        value.path = getPath(value.parent) + value.target;
    });
}
exports.updateFDFValuePaths = updateFDFValuePaths;
function assembleFDF(fdf) {
    var output = '';
    function flattenFDF(current) {
        if (!!current.kids.length) {
            current.kids.forEach(function (kid) {
                output += pdf_types_1.CFDFTagOpen + '\n';
                output += pdf_types_1.CFDFTagKids + ' [' + '\n';
                flattenFDF(kid);
                output = stripLastChars(output, '\n');
                output = stripLastChars(output, ' ');
                output += ']' + '\n';
                output += pdf_types_1.CFDFTagTarget + ' (' + kid.target + ')\n';
                output += pdf_types_1.CFDFTagClose + ' \n';
            });
        }
        current.values.forEach(function (value) {
            output +=
                pdf_types_1.CFDFTagOpen +
                    '\n' +
                    pdf_types_1.CFDFTagValue +
                    (value.value.startsWith('/') ? ' ' + value.value : ' (' + value.value + ')') +
                    '\n' +
                    pdf_types_1.CFDFTagTarget +
                    ' (' +
                    value.target +
                    ')\n' +
                    pdf_types_1.CFDFTagClose +
                    ' \n';
        });
    }
    flattenFDF(fdf);
    output = stripLastChars(output, '\n');
    output = stripLastChars(output, ' ');
    return pdf_types_1.CFDFStarter + output + pdf_types_1.CFDFTrailer;
}
exports.assembleFDF = assembleFDF;
//# sourceMappingURL=pdf.utils.js.map