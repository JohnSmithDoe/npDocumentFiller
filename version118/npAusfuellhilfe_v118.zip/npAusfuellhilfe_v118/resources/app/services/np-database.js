"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NpDatabase = void 0;
var fs = require("fs");
var NpDatabase = /** @class */ (function () {
    function NpDatabase(config) {
        this.config = config;
        this.version = 1;
        this.readDocumentDatabase();
        this.readProfilesDatabase();
        this.migrateDatabase();
    }
    Object.defineProperty(NpDatabase.prototype, "profiles", {
        get: function () {
            var _a, _b;
            return Object.values((_b = (_a = this._profiles_db) === null || _a === void 0 ? void 0 : _a.profiles) !== null && _b !== void 0 ? _b : {});
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(NpDatabase.prototype, "documents", {
        get: function () {
            var _a, _b;
            return Object.values((_b = (_a = this._database) === null || _a === void 0 ? void 0 : _a.documents) !== null && _b !== void 0 ? _b : {});
        },
        enumerable: false,
        configurable: true
    });
    NpDatabase.prototype.reset = function () {
        this._profiles_db.profiles = {};
        this._database.documents = {};
        this.writeProfilesDatabase();
        this.writeDocumentDatabase();
    };
    //<editor-fold desc="*** File handling *** ">
    NpDatabase.prototype.readDocumentDatabase = function () {
        if (fs.existsSync(this.config.DB_FILE)) {
            var content = fs.readFileSync(this.config.DB_FILE, { encoding: 'utf8' });
            console.warn(content, JSON.parse(content));
            this._database = JSON.parse(content);
        }
        else {
            console.warn('new database');
            this._database = { version: this.version, documents: {} };
        }
    };
    NpDatabase.prototype.readProfilesDatabase = function () {
        if (fs.existsSync(this.config.PROFILE_FILE)) {
            var content = fs.readFileSync(this.config.PROFILE_FILE, { encoding: 'utf8' });
            this._profiles_db = JSON.parse(content);
        }
        else {
            this._profiles_db = { version: this.version, profiles: {} };
        }
    };
    NpDatabase.prototype.migrateDatabase = function () {
        // not yet
        console.log('Database version: ' + this.version);
    };
    NpDatabase.prototype.writeDocumentDatabase = function () {
        try {
            fs.writeFileSync(this.config.DB_FILE, JSON.stringify(this._database, function (key, value) {
                if (['export', 'disabled'].includes(key))
                    return undefined;
                return value;
            }), { encoding: 'utf8' });
        }
        catch (e) {
            console.error(e);
        }
    };
    NpDatabase.prototype.writeProfilesDatabase = function () {
        try {
            fs.writeFileSync(this.config.PROFILE_FILE, JSON.stringify(this._profiles_db), { encoding: 'utf8' });
        }
        catch (e) {
            console.error(e);
        }
    };
    //</editor-fold>
    //<editor-fold desc="*** Document handling ***">
    NpDatabase.prototype.documentExists = function (filename) {
        return !!this.documents.find(function (doc) { return doc.filename === filename; });
    };
    NpDatabase.prototype.documentIdExists = function (id) {
        var _a, _b;
        return !!((_b = (_a = this._database) === null || _a === void 0 ? void 0 : _a.documents) === null || _b === void 0 ? void 0 : _b.hasOwnProperty(id));
    };
    NpDatabase.prototype.getDocument = function (id) {
        return this._database.documents[id];
    };
    NpDatabase.prototype.addDocument = function (document) {
        if (!this.documentIdExists(document.id)) {
            this._database.documents[document.id] = document;
            this.writeDocumentDatabase();
        }
        return this.documents;
    };
    NpDatabase.prototype.removeDocument = function (id) {
        if (this.documentIdExists(id)) {
            var document_1 = this._database.documents[id];
            delete this._database.documents[id];
            this.writeDocumentDatabase();
            this.updateProfilesOnDocumentRemove(document_1);
        }
        else {
            throw new Error('Document did not exist');
        }
        return this.documents;
    };
    NpDatabase.prototype.updateDocument = function (document, forceUpdate) {
        var _a, _b;
        if (forceUpdate === void 0) { forceUpdate = false; }
        if (this.documentIdExists(document.id)) {
            var original = this._database.documents[document.id];
            this._database.documents[document.id] = document;
            this.writeDocumentDatabase();
            if (forceUpdate || (((_a = original.mapped) === null || _a === void 0 ? void 0 : _a.length) !== ((_b = document.mapped) === null || _b === void 0 ? void 0 : _b.length))) {
                this.updateProfilesOnDocumentChange(document);
            }
        }
        return this.documents;
    };
    //</editor-fold>
    //<editor-fold desc="*** Profiles handling ***">
    NpDatabase.prototype.removeProfile = function (id) {
        var _a, _b;
        if (!!((_b = (_a = this._profiles_db) === null || _a === void 0 ? void 0 : _a.profiles) === null || _b === void 0 ? void 0 : _b.hasOwnProperty(id))) {
            delete this._profiles_db.profiles[id];
            this.writeProfilesDatabase();
        }
        return this.profiles;
    };
    NpDatabase.prototype.updateProfiles = function (profiles) {
        this._profiles_db.profiles = profiles.reduce(function (prev, current) {
            prev[current.id] = current;
            return prev;
        }, {});
        this.writeProfilesDatabase();
        return this.profiles;
    };
    //</editor-fold>
    NpDatabase.prototype.updateProfilesOnDocumentChange = function (document) {
        var _this = this;
        this.profiles.forEach(function (profile) {
            if (profile.documentIds.includes(document.id)) {
                profile.fieldIds = profile.fieldIds.filter(function (origId) { return _this.mappedFieldExists(origId, document); });
            }
        });
        this.writeProfilesDatabase();
    };
    NpDatabase.prototype.updateProfilesOnDocumentRemove = function (document) {
        var _this = this;
        this.profiles.forEach(function (profile) {
            if (profile.documentIds.includes(document.id)) {
                profile.documentIds.splice(profile.documentIds.indexOf(document.id), 1);
                profile.fieldIds = profile.fieldIds.filter(function (origId) { return _this.mappedFieldExists(origId); });
            }
        });
        this.writeProfilesDatabase();
    };
    NpDatabase.prototype.mappedFieldExists = function (origId, document) {
        if (document) {
            return !!document.mapped.find(function (mappedField) { return mappedField.origId === origId; });
        }
        else {
            return !!this.documents.find(function (document) { return !!document.mapped.find(function (mappedField) { return mappedField.origId === origId; }); });
        }
    };
    return NpDatabase;
}());
exports.NpDatabase = NpDatabase;
//# sourceMappingURL=np-database.js.map