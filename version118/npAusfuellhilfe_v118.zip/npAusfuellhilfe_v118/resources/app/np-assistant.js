"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.NpAssistant = void 0;
var fs = require("fs");
var path = require("path");
var path_1 = require("path");
var api_1 = require("./api");
var pdf_service_1 = require("./services/pdf/pdf.service");
var electron_utils_1 = require("./utils/electron.utils");
var shell_utils_1 = require("./utils/shell.utils");
var file_utils_1 = require("./utils/file.utils");
var np_database_1 = require("./services/np-database");
var xls_service_1 = require("./services/xls/xls.service");
var resource_service_1 = require("./services/resource/resource.service");
var args = process.argv.slice(1), debug = args.some(function (val) { return val === '--npdebug'; });
var npConfigFile = path.resolve('./.npconfig');
var npConfig = {};
try {
    var npConfigContent = fs.readFileSync(npConfigFile, { encoding: 'utf8' });
    npConfig = JSON.parse(npConfigContent);
}
catch (e) {
    console.error(e);
}
var dataPath = npConfig.DATA_PATH || process.env.APP_DATA || path.resolve('./data');
var tmpPath = npConfig.TMP_PATH || process.env.APP_TEMP || path.join(dataPath, 'tmp');
var cachePath = npConfig.CACHE_PATH || process.env.APP_CACHE || path.join(dataPath, 'cache');
var outputPath = npConfig.OUTPUT_PATH || process.env.APP_OUTPUT || path.join(dataPath, 'out');
var documentsFile = npConfig.DB_FILE || process.env.APP_CONFIG || path.join(dataPath, 'data.db');
var profilesFile = npConfig.PROFILE_FILE || process.env.APP_CONFIG || path.join(dataPath, 'profiles.db');
// Get the pdftk.exe
var pdftk = npConfig.PDFTK_EXE || process.env.APP_PDFTK_EXE || (0, path_1.resolve)((0, path_1.join)('.', 'pdftk', 'bin', 'pdftk.exe'));
// To get the encoding of a file we need to "guess" so we only split win and others :)
var encoding = npConfig.ENCODING || process.env.APP_ENCODING || (process.platform === 'win32' ? 'win1252' : 'utf8');
npConfig.DATA_PATH = dataPath;
npConfig.TMP_PATH = tmpPath;
npConfig.CACHE_PATH = cachePath;
npConfig.OUTPUT_PATH = outputPath;
npConfig.DB_FILE = documentsFile;
npConfig.PROFILE_FILE = profilesFile;
npConfig.PDFTK_EXE = pdftk;
npConfig.ENCODING = encoding;
if (debug) {
    console.log(npConfig, pdftk);
    try {
        fs.writeFileSync(npConfigFile, JSON.stringify(npConfig), { encoding: 'utf8' });
    }
    catch (e) {
        console.error(e);
    }
}
// init folder structure
if (!fs.existsSync(dataPath)) {
    fs.mkdirSync(dataPath);
}
if (!fs.existsSync(tmpPath)) {
    fs.mkdirSync(tmpPath);
}
if (!fs.existsSync(cachePath)) {
    fs.mkdirSync(cachePath);
}
if (!fs.existsSync(outputPath)) {
    fs.mkdirSync(outputPath);
}
var NpAssistant = /** @class */ (function () {
    function NpAssistant(mainWindow) {
        this.mainWindow = mainWindow;
        this.api = new api_1.ApiController(this, npConfig);
        this.database = new np_database_1.NpDatabase(npConfig);
        this.pdf = new pdf_service_1.PdfService(npConfig);
        this.xls = new xls_service_1.XlsService(npConfig);
        this.resource = new resource_service_1.ResourceService(npConfig);
    }
    NpAssistant.prototype.getClientData = function (documents, profiles, message) {
        return {
            documents: documents ? this.database.documents : [],
            profiles: profiles ? this.database.profiles : [],
            message: message,
        };
    };
    NpAssistant.prototype.updateProfiles = function (profiles) {
        this.database.updateProfiles(profiles);
        return this.getClientData(false, true, { headline: 'Profile wurden erfolgreich aktualisiert', messages: [] });
    };
    NpAssistant.prototype.addDocument = function (filename, autoMapFields, preview) {
        return __awaiter(this, void 0, void 0, function () {
            var type, document, _a;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        if (!fs.existsSync(filename))
                            throw new Error('Die gewählte Datei konnte nicht gelesen werden. Bitte wenden Sie sich an Ihren persönlichen Ansprechpartner für IT-Probleme.');
                        if (this.database.documentExists(filename))
                            throw new Error('Dieses Dokument existiert bereits. Bitte keine doppelten Dokumente anlegen. Bei Problemen entferne die alte Vorlage und beginne von vorne.');
                        type = (0, file_utils_1.getFileInfo)(filename).type;
                        _a = type;
                        switch (_a) {
                            case "pdf": return [3 /*break*/, 1];
                            case "xlsx": return [3 /*break*/, 3];
                            case "resource": return [3 /*break*/, 5];
                        }
                        return [3 /*break*/, 7];
                    case 1:
                        this.pdf.autoMapFields = autoMapFields;
                        return [4 /*yield*/, this.pdf.addDocument(filename)];
                    case 2:
                        document = _b.sent();
                        if (preview)
                            (0, shell_utils_1.startWithExpolorer)(document.previewfile);
                        return [3 /*break*/, 7];
                    case 3: return [4 /*yield*/, this.xls.addDocument(filename)];
                    case 4:
                        document = _b.sent();
                        return [3 /*break*/, 7];
                    case 5: return [4 /*yield*/, this.resource.addDocument(filename)];
                    case 6:
                        document = _b.sent();
                        return [3 /*break*/, 7];
                    case 7:
                        this.database.addDocument(document);
                        return [2 /*return*/];
                }
            });
        });
    };
    NpAssistant.prototype.addDocuments = function (autoMapFields, wholeFolder) {
        return __awaiter(this, void 0, void 0, function () {
            var headline, folderName, filenames, i, filename, filename;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!wholeFolder) return [3 /*break*/, 6];
                        folderName = (0, electron_utils_1.showFolderPickerSync)(this.mainWindow, { defaultPath: '', title: 'Ordner verknüpfen' });
                        if (!folderName) return [3 /*break*/, 5];
                        filenames = (0, file_utils_1.getFilesFromFolderSync)(folderName);
                        i = 0;
                        _a.label = 1;
                    case 1:
                        if (!(i < filenames.length)) return [3 /*break*/, 4];
                        filename = path.join(folderName, filenames[i]);
                        return [4 /*yield*/, this.addDocument(filename, autoMapFields, false)];
                    case 2:
                        _a.sent();
                        _a.label = 3;
                    case 3:
                        i++;
                        return [3 /*break*/, 1];
                    case 4:
                        headline = 'Ordner wurde erfolgreich hinzugefügt';
                        _a.label = 5;
                    case 5: return [3 /*break*/, 8];
                    case 6:
                        filename = (0, electron_utils_1.showFilePickerSync)(this.mainWindow, { defaultPath: '', title: 'Dokument verknüpfen' });
                        if (!filename) return [3 /*break*/, 8];
                        return [4 /*yield*/, this.addDocument(filename, autoMapFields, true)];
                    case 7:
                        _a.sent();
                        headline = 'Dokument wurde erfolgreich hinzugefügt';
                        _a.label = 8;
                    case 8: return [2 /*return*/, this.getClientData(true, false, headline ? { headline: headline, messages: [] } : undefined)];
                }
            });
        });
    };
    NpAssistant.prototype.createDocuments = function (foldername, documentIds, inputs) {
        return __awaiter(this, void 0, void 0, function () {
            var outputFolder, _a, outputMsgs, valid, documents, _i, documents_1, document_1, basename, _b, e_1;
            return __generator(this, function (_c) {
                switch (_c.label) {
                    case 0:
                        outputFolder = path.join(outputPath, foldername);
                        _a = (0, file_utils_1.createAndValidateFolder)(outputFolder), outputMsgs = _a.outputMsgs, valid = _a.valid;
                        if (!valid)
                            throw new Error(outputMsgs.join('||'));
                        documents = this.database.documents.filter(function (doc) { return documentIds.includes(doc.id); });
                        _i = 0, documents_1 = documents;
                        _c.label = 1;
                    case 1:
                        if (!(_i < documents_1.length)) return [3 /*break*/, 12];
                        document_1 = documents_1[_i];
                        _c.label = 2;
                    case 2:
                        _c.trys.push([2, 10, , 11]);
                        basename = void 0;
                        _b = document_1.type;
                        switch (_b) {
                            case "pdf": return [3 /*break*/, 3];
                            case "xlsx": return [3 /*break*/, 5];
                            case "resource": return [3 /*break*/, 7];
                        }
                        return [3 /*break*/, 9];
                    case 3: return [4 /*yield*/, this.pdf.createDocument(document_1, outputFolder, inputs, outputMsgs)];
                    case 4:
                        basename = _c.sent();
                        return [3 /*break*/, 9];
                    case 5: return [4 /*yield*/, this.xls.createDocument(document_1, outputFolder, inputs, outputMsgs)];
                    case 6:
                        basename = _c.sent();
                        return [3 /*break*/, 9];
                    case 7: return [4 /*yield*/, this.resource.createDocument(document_1, outputFolder, inputs, outputMsgs)];
                    case 8:
                        basename = _c.sent();
                        return [3 /*break*/, 9];
                    case 9:
                        outputMsgs.push("Dokument wurden erstellt: ".concat(basename));
                        return [3 /*break*/, 11];
                    case 10:
                        e_1 = _c.sent();
                        outputMsgs.push('Beim erstellen von: ' + document_1.name + ' ist ein Fehler aufgetreten.');
                        outputMsgs.push('Folgende Felder wurden erwartet: ' + document_1.mapped.map(function (item) { return item.mappedName; }).join(', '));
                        outputMsgs.push('Debug Info:' + inputs.map(function (item) { return item.identifiers.join(', '); }).join('; '));
                        return [3 /*break*/, 11];
                    case 11:
                        _i++;
                        return [3 /*break*/, 1];
                    case 12:
                        outputMsgs.push("Alle Dokumente wurden erfolgreich erstellt.");
                        return [2 /*return*/, this.getClientData(false, false, {
                                headline: 'Dokumente wurden erfolgreich erstellt',
                                messages: outputMsgs,
                                messageFolder: outputFolder
                            })];
                }
            });
        });
    };
    NpAssistant.prototype.removeDocument = function (id, removeEverything) {
        var headline = 'Dokument wurde erfolgreich entfernt';
        if (typeof id === 'number') {
            if (id === -1 && removeEverything) {
                this.database.reset();
                headline = 'System wurde erfolgreich zurückgesetzt';
            }
        }
        else {
            this.database.removeDocument(id);
        }
        return this.getClientData(true, true, { headline: headline, messages: [] });
    };
    NpAssistant.prototype.updateDocument = function (document) {
        this.database.updateDocument(document);
        return this.getClientData(true, true, { headline: 'Dokument wurde erfolgreich gespeichert', messages: [] });
    };
    NpAssistant.prototype.remapDocument = function (id) {
        return __awaiter(this, void 0, void 0, function () {
            var original, newfilename, _a, basename, type, outputMsgs, _b;
            return __generator(this, function (_c) {
                switch (_c.label) {
                    case 0:
                        if (!this.database.documentIdExists(id))
                            throw new Error('Dieses Dokument existiert nicht mehr. Bitte wenden Sie sich an Ihren persönlichen Ansprechpartner für IT-Probleme.');
                        original = this.database.getDocument(id);
                        newfilename = (0, electron_utils_1.showFilePickerSync)(this.mainWindow, {
                            defaultPath: path.dirname(original.filename), title: 'Dokument neu verknüpfen'
                        });
                        if (!newfilename)
                            return [2 /*return*/];
                        if (!fs.existsSync(newfilename))
                            throw new Error('Die gewählte Datei konnte nicht gelesen werden. Bitte wenden Sie sich an Ihren persönlichen Ansprechpartner für IT-Probleme.');
                        _a = (0, file_utils_1.getFileInfo)(newfilename), basename = _a.basename, type = _a.type;
                        if (type !== original.type)
                            throw new Error('Es kann hier nur eine Änderung des Dateinamens vorgenommen werden. Eine Änderung des Vorlagen-Typs geht nur über löschen und neu anlegen.');
                        outputMsgs = [];
                        _b = original.type;
                        switch (_b) {
                            case "pdf": return [3 /*break*/, 1];
                            case "xlsx": return [3 /*break*/, 3];
                            case "resource": return [3 /*break*/, 5];
                        }
                        return [3 /*break*/, 7];
                    case 1: return [4 /*yield*/, this.pdf.remapDocument(original, newfilename)];
                    case 2:
                        _c.sent();
                        return [3 /*break*/, 7];
                    case 3: return [4 /*yield*/, this.xls.remapDocument(original, newfilename)];
                    case 4:
                        _c.sent();
                        return [3 /*break*/, 7];
                    case 5: return [4 /*yield*/, this.resource.remapDocument(original, newfilename)];
                    case 6:
                        _c.sent();
                        return [3 /*break*/, 7];
                    case 7:
                        outputMsgs.push("Dokument wurde neu verkn\u00FCpft mit: ".concat(basename));
                        this.database.updateDocument(original, true);
                        return [2 /*return*/, this.getClientData(true, true, { headline: 'Dokument wurde erfolgreich neu verknüpft', messages: outputMsgs })];
                }
            });
        });
    };
    return NpAssistant;
}());
exports.NpAssistant = NpAssistant;
//# sourceMappingURL=np-assistant.js.map