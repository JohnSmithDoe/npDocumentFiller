"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createAndValidateFolder = exports.getFilesFromFolderSync = exports.getFileStats = exports.getFileInfo = exports.removeTempCopy = exports.copyToTempFolder = void 0;
var fs = require("fs");
var path = require("path");
function copyToTempFolder(filename, tmpPath) {
    var basename = path.basename(filename);
    var tmpCopy = path.join(tmpPath, basename);
    fs.copyFileSync(filename, tmpCopy);
    return tmpCopy;
}
exports.copyToTempFolder = copyToTempFolder;
function removeTempCopy(filename, tmpPath, dryrun) {
    if (dryrun === void 0) { dryrun = false; }
    var basename = path.basename(filename);
    var tmpCopy = path.join(tmpPath, basename);
    if (!dryrun)
        fs.rmSync(tmpCopy);
    return tmpCopy;
}
exports.removeTempCopy = removeTempCopy;
function getFileInfo(filename) {
    var ext = path.extname(filename);
    var basename = path.basename(filename);
    var basenameNoExt = path.basename(filename, ext);
    var type = ext === '.pdf' ? 'pdf' : ext === '.xlsx' ? 'xlsx' : 'resource';
    return { basename: basename, basenameNoExt: basenameNoExt, type: type };
}
exports.getFileInfo = getFileInfo;
function getFileStats(filename) {
    var mtimeMs = fs.statSync(filename).mtimeMs;
    return __assign(__assign({}, getFileInfo(filename)), { mtimeMs: mtimeMs });
}
exports.getFileStats = getFileStats;
function getFilesFromFolderSync(foldername) {
    return fs.readdirSync(foldername);
}
exports.getFilesFromFolderSync = getFilesFromFolderSync;
function createAndValidateFolder(outputFolder) {
    var result = [];
    var valid = true;
    if (!fs.existsSync(outputFolder)) {
        fs.mkdirSync(outputFolder);
        result.push("Ordner wurde erstellt: ".concat(outputFolder));
    }
    else {
        valid = false;
        result.push("Ordner existierte bereits: ".concat(outputFolder));
        result.push('Erstellen wurde abgebrochen damit keine Daten überschrieben werden.');
        result.push('Bitte warte eine Minute, lösche den Ordner oder verwende ein anderes suffix');
    }
    return { outputMsgs: result, valid: valid };
}
exports.createAndValidateFolder = createAndValidateFolder;
//# sourceMappingURL=file.utils.js.map