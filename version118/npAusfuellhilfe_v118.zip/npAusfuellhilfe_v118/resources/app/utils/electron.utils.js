"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.showFolderPickerSync = exports.showFilePickerSync = void 0;
var electron_1 = require("electron");
function showFilePickerSync(mainWindow, options) {
    var result = null;
    if (mainWindow) {
        var filename = electron_1.dialog.showOpenDialogSync(mainWindow, __assign(__assign({}, options), { properties: ['openFile'] }));
        result = (filename === null || filename === void 0 ? void 0 : filename.pop()) || null;
    }
    return result;
}
exports.showFilePickerSync = showFilePickerSync;
function showFolderPickerSync(mainWindow, options) {
    var result = null;
    if (mainWindow) {
        var filename = electron_1.dialog.showOpenDialogSync(mainWindow, __assign(__assign({}, options), { properties: ['openDirectory'] }));
        result = (filename === null || filename === void 0 ? void 0 : filename.pop()) || null;
    }
    return result;
}
exports.showFolderPickerSync = showFolderPickerSync;
//# sourceMappingURL=electron.utils.js.map